import React, { useRef, useEffect, useMemo, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';
import { 
  AlertTriangle, 
  Monitor, 
  Server, 
  Laptop, 
  Smartphone, 
  Router as RouterIcon,
  Database,
  Printer,
  Network,
  HardDrive,
  Wifi,
  Globe,
  Activity,
  ZoomIn,
  ZoomOut,
  Search
} from 'lucide-react';

interface Port {
  port: number;
  state: string;
  service: string;
  version: string;
  product: string;
}

interface Device {
  ip: string;
  hostname: string;
  os: {
    name: string;
    accuracy: number;
    family: string;
  };
  ports: Port[];
  status: string;
  last_seen: number;
  hypervisor?: {
    type: 'vm' | 'hypervisor';
    name?: string;
    hypervisor?: string;
    parent?: string;
  };
}

interface NetworkData {
  devices: Device[];
  metrics: {
    cpu_usage: number;
    memory_total: number;
    memory_used: number;
    memory_free: number;
  };
  timestamp: number;
}

interface NetworkMapProps {
  networkData: NetworkData | null;
}

function calculateNodePosition(index: number, total: number, radius: number = 3, isVM: boolean = false, parentPos?: [number, number, number]): [number, number, number] {
  if (isVM && parentPos) {
    const vmAngle = (index * Math.PI * 2) / total;
    const vmRadius = 1;
    const x = parentPos[0] + Math.cos(vmAngle) * vmRadius;
    const y = parentPos[1] + Math.sin(vmAngle) * vmRadius;
    const z = parentPos[2];
    return [x, y, z];
  }

  const phi = Math.acos(-1 + (2 * index) / total);
  const theta = Math.sqrt(total * Math.PI) * phi;
  
  const x = radius * Math.cos(theta) * Math.sin(phi);
  const y = radius * Math.sin(theta) * Math.sin(phi);
  const z = radius * Math.cos(phi);
  
  return [x, y, z];
}

function getDeviceIcon(device: Device) {
  const hostname = device.hostname.toLowerCase();
  const osName = device.os.name.toLowerCase();
  const ports = device.ports.map(p => p.port);

  if (device.hypervisor?.type === 'hypervisor') {
    return Server;
  }

  if (device.hypervisor?.type === 'vm') {
    return Monitor;
  }

  if (ports.includes(3389) || hostname.includes('desktop') || osName.includes('windows')) {
    return Monitor;
  }

  if (ports.includes(22) || hostname.includes('server') || hostname.includes('srv')) {
    return Server;
  }

  if (hostname.includes('printer') || ports.includes(631)) {
    return Printer;
  }

  if (hostname.includes('nas') || hostname.includes('storage')) {
    return Database;
  }

  if (hostname.includes('mobile') || hostname.includes('phone')) {
    return Smartphone;
  }

  if (hostname.includes('laptop')) {
    return Laptop;
  }

  return HardDrive;
}

function Node({ device, position, isVM = false }: { device: Device; position: [number, number, number]; isVM?: boolean }) {
  const [hovered, setHovered] = React.useState(false);
  const DeviceIcon = getDeviceIcon(device);

  const getNodeColor = (status: string) => {
    switch (status) {
      case 'compromised': return '#ff0033';
      case 'warning': return '#f59e0b';
      default: return '#00f7ff';
    }
  };

  const scale = isVM ? 0.7 : 1;
  const color = getNodeColor(device.status);

  return (
    <group position={position}>
      <Html center>
        <div 
          className={`device-icon transform transition-transform duration-200 ${hovered ? 'scale-125' : 'scale-100'}`}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
        >
          <DeviceIcon 
            className="h-6 w-6"
            style={{ 
              color,
              filter: `drop-shadow(0 0 4px ${color})`,
              opacity: hovered ? 1 : 0.8,
            }}
          />
        </div>
      </Html>

      {device.ports.map((port, index) => (
        <PortRing
          key={port.port}
          port={port.port}
          index={index}
          total={device.ports.length}
          radius={0.6 * scale}
        />
      ))}

      {device.hypervisor && (
        <Html position={[0, 0.5, 0]} center>
          <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded flex items-center gap-1">
            <Monitor className="h-3 w-3" />
            <span>{device.hypervisor.type === 'hypervisor' ? 'Hypervisor' : 'VM'}</span>
          </div>
        </Html>
      )}

      <Html position={[0, -0.8, 0]} center>
        <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded">
          {device.ip}
        </div>
      </Html>

      {hovered && (
        <Html position={[0, 0.8, 0]}>
          <div className="bg-[#111111] border border-[#00f7ff] p-2 rounded text-xs text-[#00f7ff] whitespace-nowrap">
            <div>{device.hostname}</div>
            <div>OS: {device.os.name}</div>
            <div>Ports: {device.ports.map(p => p.port).join(', ')}</div>
            {device.hypervisor && (
              <div>
                {device.hypervisor.type === 'vm' ? (
                  <>VM ({device.hypervisor.hypervisor})</>
                ) : (
                  <>Hypervisor ({device.hypervisor.name})</>
                )}
              </div>
            )}
            <div className={`capitalize ${device.status === 'compromised' ? 'text-[#ff0033]' : ''}`}>
              Status: {device.status}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function PortRing({ port, index, total, radius = 0.5 }) {
  const ref = useRef();
  const angle = (index / total) * Math.PI * 2;
  const x = Math.cos(angle) * radius;
  const y = Math.sin(angle) * radius;

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z += 0.02;
      ref.current.scale.x = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
      ref.current.scale.y = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
    }
  });

  return (
    <group position={[x, y, 0]}>
      <mesh ref={ref}>
        <ringGeometry args={[0.08, 0.1, 32]} />
        <meshStandardMaterial
          color="#00f7ff"
          emissive="#00f7ff"
          emissiveIntensity={1}
          transparent
          opacity={0.8}
        />
      </mesh>
      <Html position={[0, 0, 0]} center>
        <div className="text-[#00f7ff] text-[10px] whitespace-nowrap">
          :{port}
        </div>
      </Html>
    </group>
  );
}

function VMConnection({ start, end }) {
  const ref = useRef();

  useFrame((state) => {
    if (ref.current) {
      ref.current.material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });

  return (
    <line ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={2}
          array={new Float32Array([...start, ...end])}
          itemSize={3}
        />
      </bufferGeometry>
      <lineBasicMaterial color="#00ff00" opacity={0.3} transparent />
    </line>
  );
}

function RouterInfo() {
  return (
    <div className="bg-[#111111]/90 border border-[#00ff00] p-3 rounded-lg shadow-lg backdrop-blur-sm">
      <div className="flex items-center space-x-2 mb-2 text-[#00ff00]">
        <RouterIcon className="h-5 w-5" />
        <span className="font-bold">Main Router</span>
      </div>
      
      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-[#00ff00]" />
            <span>WAN IP</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.1</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wifi className="h-4 w-4 text-[#00ff00]" />
            <span>Network</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.0/24</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="h-4 w-4 text-[#00ff00]" />
            <span>Status</span>
          </div>
          <span className="text-[#00ff00]">Active</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Network className="h-4 w-4 text-[#00ff00]" />
            <span>Connected Devices</span>
          </div>
          <span className="text-[#00ff00]">24</span>
        </div>
      </div>
    </div>
  );
}

function DataPacket({ start, end, speed = 1 }) {
  const ref = useRef();
  const [progress, setProgress] = useState(0);

  useFrame((state) => {
    if (ref.current) {
      // Update packet position
      setProgress((prev) => (prev + speed * 0.01) % 1);
      
      // Interpolate position
      const x = start[0] + (end[0] - start[0]) * progress;
      const y = start[1] + (end[1] - start[1]) * progress;
      const z = start[2] + (end[2] - start[2]) * progress;
      
      ref.current.position.set(x, y, z);
      
      // Pulse effect
      const scale = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.2;
      ref.current.scale.set(scale, scale, scale);
    }
  });

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[0.05, 16, 16]} />
      <meshStandardMaterial
        color="#00ff00"
        emissive="#00ff00"
        emissiveIntensity={2}
        transparent
        opacity={0.8}
      />
    </mesh>
  );
}

function DataStream({ start, end }) {
  const ref = useRef();
  const curve = useMemo(() => {
    const points = [
      new THREE.Vector3(...start),
      new THREE.Vector3(...end),
    ];
    return new THREE.CatmullRomCurve3(points);
  }, [start, end]);

  useFrame((state) => {
    if (ref.current) {
      // Animate dash offset
      ref.current.material.dashOffset -= 0.01;
      
      // Pulse opacity
      ref.current.material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 2) * 0.1;
    }
  });

  return (
    <group>
      <mesh>
        <tubeGeometry args={[curve, 64, 0.02, 8, false]} />
        <meshStandardMaterial
          ref={ref}
          color="#00ff00"
          transparent
          opacity={0.4}
          dashSize={0.1}
          gapSize={0.1}
          onBeforeCompile={(shader) => {
            shader.fragmentShader = shader.fragmentShader.replace(
              'void main() {',
              `
              uniform float dashOffset;
              void main() {
                if (mod(vUv.x * 10.0 + dashOffset, 1.0) > 0.5) discard;
              `
            );
          }}
        />
      </mesh>
      <DataPacket start={start} end={end} />
      <DataPacket start={end} end={start} speed={0.8} />
    </group>
  );
}

function Scene({ networkData, textScale, onTextScaleChange }) {
  const { camera, size } = useThree();
  const [showRouterInfo, setShowRouterInfo] = useState(false);
  const [hoveredDevice, setHoveredDevice] = useState(null);
  const orbitControlsRef = useRef();

  useEffect(() => {
    camera.position.set(0, 0, 10);
    camera.lookAt(0, 0, 0);
  }, [camera]);

  const handleZoomIn = () => {
    onTextScaleChange(Math.min(textScale + 0.1, 2.0));
  };

  const handleZoomOut = () => {
    onTextScaleChange(Math.max(textScale - 0.1, 0.5));
  };

  // Calculate base font size based on screen size and zoom
  const baseFontSize = Math.max(14 * textScale, Math.min(24 * textScale, size.width / 50));

  if (!networkData?.devices) {
    return null;
  }

  return (
    <group>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1.5} />

      {/* Router */}
      <group
        onPointerOver={() => setShowRouterInfo(true)}
        onPointerOut={() => setShowRouterInfo(false)}
      >
        <Html center>
          <div 
            className="device-icon transform scale-125"
            style={{ fontSize: `${baseFontSize}px` }}
          >
            <RouterIcon 
              className="h-8 w-8"
              style={{ 
                color: '#00ff00',
                filter: 'drop-shadow(0 0 6px #00ff00)',
              }}
            />
          </div>
          {showRouterInfo && (
            <div 
              className="absolute top-10 left-1/2 transform -translate-x-1/2 z-50 whitespace-nowrap"
              style={{ fontSize: `${baseFontSize * 0.8}px` }}
            >
              <RouterInfo />
            </div>
          )}
        </Html>
      </group>

      {/* Data Streams */}
      {networkData.devices.map(device => {
        const devicePos = calculateNodePosition(0, 1, 3);
        const isHovered = hoveredDevice === device.ip;
        
        return (
          <group key={`connection-${device.ip}`}>
            <DataStream
              start={[0, 0, 0]}
              end={devicePos}
              isActive={isHovered}
            />
          </group>
        );
      })}

      {/* Devices */}
      {networkData.devices.map((device, i) => (
        <Node
          key={device.ip}
          device={device}
          position={calculateNodePosition(i, networkData.devices.length, 4)}
          onHover={(isHovered) => setHoveredDevice(isHovered ? device.ip : null)}
          textScale={textScale}
          fontSize={baseFontSize}
        />
      ))}

      {/* Zoom Controls */}
      <Html
        position={[0, 0, 0]}
        style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          width: 'auto',
          pointerEvents: 'auto'
        }}
      >
        <div className="cyber-panel p-2 flex flex-col space-y-2">
          <div className="flex items-center justify-between space-x-2 px-2">
            <Search className="h-4 w-4 text-[#00ff00]" />
            <span className="text-xs">Text Scale: {textScale.toFixed(1)}x</span>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={handleZoomOut}
              className="p-2 bg-[#111111] border border-[#00ff00] rounded hover:bg-[#222222] transition-colors"
              disabled={textScale <= 0.5}
            >
              <ZoomOut className="h-4 w-4 text-[#00ff00]" />
            </button>
            <button
              onClick={handleZoomIn}
              className="p-2 bg-[#111111] border border-[#00ff00] rounded hover:bg-[#222222] transition-colors"
              disabled={textScale >= 2.0}
            >
              <ZoomIn className="h-4 w-4 text-[#00ff00]" />
            </button>
          </div>
        </div>
      </Html>

      <OrbitControls
        ref={orbitControlsRef}
        enableZoom={true}
        minDistance={5}
        maxDistance={20}
        enablePan={false}
        onChange={() => {
          // Update text scale based on camera distance
          const distance = camera.position.distanceTo(new THREE.Vector3(0, 0, 0));
          const newScale = 1 + (1 - distance / 20); // Scale text up as we zoom in
          onTextScaleChange(Math.max(0.5, Math.min(2.0, newScale)));
        }}
      />
    </group>
  );
}

export function NetworkMap({ networkData }: NetworkMapProps) {
  const [textScale, setTextScale] = useState(1.0);
  const hasCompromisedDevices = networkData?.devices.some(d => d.status === 'compromised');

  const scaledStyle = {
    fontSize: `${textScale}em`,
  };

  return (
    <div className="cyber-panel h-[600px] relative grid-bg">
      <Canvas>
        <Scene 
          networkData={networkData} 
          textScale={textScale}
          onTextScaleChange={setTextScale}
        />
      </Canvas>
      
      {hasCompromisedDevices && (
        <div 
          className="absolute top-4 right-4 flex items-center space-x-2 text-[#ff0033]"
          style={scaledStyle}
        >
          <AlertTriangle className="h-5 w-5" />
          <span>THREAT DETECTED</span>
        </div>
      )}
      
      <div 
        className="absolute bottom-4 left-4 text-xs"
        style={scaledStyle}
      >
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-2">
            <RouterIcon className="h-4 w-4 text-[#00ff00]" />
            <span>Router</span>
          </div>
          <div className="flex items-center space-x-2">
            <Server className="h-4 w-4 text-[#00f7ff]" />
            <span>Server</span>
          </div>
          <div className="flex items-center space-x-2">
            <Monitor className="h-4 w-4 text-[#00f7ff]" />
            <span>Desktop/VM</span>
          </div>
          <div className="flex items-center space-x-2">
            <Laptop className="h-4 w-4 text-[#00f7ff]" />
            <span>Laptop</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-[#00f7ff]" />
            <span>Storage</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#ff0033]"></div>
            <span>Compromised</span>
          </div>
        </div>
      </div>
    </div>
  );
}