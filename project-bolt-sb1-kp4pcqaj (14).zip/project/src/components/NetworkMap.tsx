import React, { useRef, useEffect, useMemo } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';
import { 
  AlertTriangle, 
  Monitor, 
  Server, 
  Laptop, 
  Smartphone, 
  Router as RouterIcon,
  Database,
  Printer,
  Network,
  HardDrive,
  Wifi,
  Globe,
  Activity,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

interface Port {
  port: number;
  state: string;
  service: string;
  version: string;
  product: string;
}

interface Device {
  ip: string;
  hostname: string;
  os: {
    name: string;
    accuracy: number;
    family: string;
  };
  ports: Port[];
  status: string;
  last_seen: number;
  hypervisor?: {
    type: 'vm' | 'hypervisor';
    name?: string;
    hypervisor?: string;
    parent?: string;
  };
}

interface NetworkData {
  devices: Device[];
  metrics: {
    cpu_usage: number;
    memory_total: number;
    memory_used: number;
    memory_free: number;
  };
  timestamp: number;
}

interface NetworkMapProps {
  networkData: NetworkData | null;
}

function calculateNodePosition(index: number, total: number, radius: number = 3, isVM: boolean = false, parentPos?: [number, number, number]): [number, number, number] {
  if (isVM && parentPos) {
    const vmAngle = (index * Math.PI * 2) / total;
    const vmRadius = 1;
    const x = parentPos[0] + Math.cos(vmAngle) * vmRadius;
    const y = parentPos[1] + Math.sin(vmAngle) * vmRadius;
    const z = parentPos[2];
    return [x, y, z];
  }

  const phi = Math.acos(-1 + (2 * index) / total);
  const theta = Math.sqrt(total * Math.PI) * phi;
  
  const x = radius * Math.cos(theta) * Math.sin(phi);
  const y = radius * Math.sin(theta) * Math.sin(phi);
  const z = radius * Math.cos(phi);
  
  return [x, y, z];
}

function getDeviceIcon(device: Device) {
  const hostname = device.hostname.toLowerCase();
  const osName = device.os.name.toLowerCase();
  const ports = device.ports.map(p => p.port);

  if (device.hypervisor?.type === 'hypervisor') {
    return Server;
  }

  if (device.hypervisor?.type === 'vm') {
    return Monitor;
  }

  if (ports.includes(3389) || hostname.includes('desktop') || osName.includes('windows')) {
    return Monitor;
  }

  if (ports.includes(22) || hostname.includes('server') || hostname.includes('srv')) {
    return Server;
  }

  if (hostname.includes('printer') || ports.includes(631)) {
    return Printer;
  }

  if (hostname.includes('nas') || hostname.includes('storage')) {
    return Database;
  }

  if (hostname.includes('mobile') || hostname.includes('phone')) {
    return Smartphone;
  }

  if (hostname.includes('laptop')) {
    return Laptop;
  }

  return HardDrive;
}

function Node({ device, position, isVM = false }: { device: Device; position: [number, number, number]; isVM?: boolean }) {
  const [hovered, setHovered] = React.useState(false);
  const DeviceIcon = getDeviceIcon(device);

  const getNodeColor = (status: string) => {
    switch (status) {
      case 'compromised': return '#ff0033';
      case 'warning': return '#f59e0b';
      default: return '#00f7ff';
    }
  };

  const scale = isVM ? 0.7 : 1;
  const color = getNodeColor(device.status);

  return (
    <group position={position}>
      <Html center>
        <div 
          className={`device-icon transform transition-transform duration-200 ${hovered ? 'scale-125' : 'scale-100'}`}
          onPointerOver={() => setHovered(true)}
          onPointerOut={() => setHovered(false)}
        >
          <DeviceIcon 
            className="h-6 w-6"
            style={{ 
              color,
              filter: `drop-shadow(0 0 4px ${color})`,
              opacity: hovered ? 1 : 0.8,
            }}
          />
        </div>
      </Html>

      {device.ports.map((port, index) => (
        <PortRing
          key={port.port}
          port={port.port}
          index={index}
          total={device.ports.length}
          radius={0.6 * scale}
        />
      ))}

      {device.hypervisor && (
        <Html position={[0, 0.5, 0]} center>
          <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded flex items-center gap-1">
            <Monitor className="h-3 w-3" />
            <span>{device.hypervisor.type === 'hypervisor' ? 'Hypervisor' : 'VM'}</span>
          </div>
        </Html>
      )}

      <Html position={[0, -0.8, 0]} center>
        <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded">
          {device.ip}
        </div>
      </Html>

      {hovered && (
        <Html position={[0, 0.8, 0]}>
          <div className="bg-[#111111] border border-[#00f7ff] p-2 rounded text-xs text-[#00f7ff] whitespace-nowrap">
            <div>{device.hostname}</div>
            <div>OS: {device.os.name}</div>
            <div>Ports: {device.ports.map(p => p.port).join(', ')}</div>
            {device.hypervisor && (
              <div>
                {device.hypervisor.type === 'vm' ? (
                  <>VM ({device.hypervisor.hypervisor})</>
                ) : (
                  <>Hypervisor ({device.hypervisor.name})</>
                )}
              </div>
            )}
            <div className={`capitalize ${device.status === 'compromised' ? 'text-[#ff0033]' : ''}`}>
              Status: {device.status}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function PortRing({ port, index, total, radius = 0.5 }) {
  const ref = useRef();
  const angle = (index / total) * Math.PI * 2;
  const x = Math.cos(angle) * radius;
  const y = Math.sin(angle) * radius;

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z += 0.02;
      ref.current.scale.x = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
      ref.current.scale.y = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.2;
    }
  });

  return (
    <group position={[x, y, 0]}>
      <mesh ref={ref}>
        <ringGeometry args={[0.08, 0.1, 32]} />
        <meshStandardMaterial
          color="#00f7ff"
          emissive="#00f7ff"
          emissiveIntensity={1}
          transparent
          opacity={0.8}
        />
      </mesh>
      <Html position={[0, 0, 0]} center>
        <div className="text-[#00f7ff] text-[10px] whitespace-nowrap">
          :{port}
        </div>
      </Html>
    </group>
  );
}

function VMConnection({ start, end }) {
  const ref = useRef();

  useFrame((state) => {
    if (ref.current) {
      ref.current.material.opacity = 0.3 + Math.sin(state.clock.elapsedTime * 2) * 0.2;
    }
  });

  return (
    <line ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={2}
          array={new Float32Array([...start, ...end])}
          itemSize={3}
        />
      </bufferGeometry>
      <lineBasicMaterial color="#00ff00" opacity={0.3} transparent />
    </line>
  );
}

function Scene({ networkData }: { networkData: NetworkData | null }) {
  const { camera } = useThree();
  const [showRouterInfo, setShowRouterInfo] = React.useState(false);
  const orbitControlsRef = useRef();
  
  useEffect(() => {
    camera.position.set(0, 0, 10);
    camera.lookAt(0, 0, 0);
  }, [camera]);

  const handleZoomIn = () => {
    if (orbitControlsRef.current) {
      orbitControlsRef.current.object.position.z *= 0.8;
    }
  };

  const handleZoomOut = () => {
    if (orbitControlsRef.current) {
      orbitControlsRef.current.object.position.z *= 1.2;
    }
  };

  if (!networkData?.devices) {
    return null;
  }

  const hypervisors = [];
  const vms = [];
  const others = [];

  networkData.devices.forEach(device => {
    if (device.hypervisor?.type === 'hypervisor') {
      hypervisors.push(device);
    } else if (device.hypervisor?.type === 'vm') {
      vms.push(device);
    } else {
      others.push(device);
    }
  });

  const hypervisorPositions = new Map<string, [number, number, number]>();
  
  hypervisors.forEach((hypervisor, i) => {
    const pos = calculateNodePosition(i, hypervisors.length, 5);
    hypervisorPositions.set(hypervisor.ip, pos);
  });

  return (
    <group position={[0, 0, 0]}>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1.5} />
      
      <group
        onPointerOver={() => setShowRouterInfo(true)}
        onPointerOut={() => setShowRouterInfo(false)}
      >
        <Html center>
          <div className="device-icon transform scale-125">
            <RouterIcon 
              className="h-8 w-8"
              style={{ 
                color: '#00ff00',
                filter: 'drop-shadow(0 0 6px #00ff00)',
              }}
            />
          </div>
          {showRouterInfo && (
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 z-50 whitespace-nowrap">
              <RouterInfo />
            </div>
          )}
        </Html>
      </group>

      {networkData.devices.map(device => (
        <line key={`router-connection-${device.ip}`}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={2}
              array={new Float32Array([0, 0, 0, ...calculateNodePosition(0, 1, 3)])}
              itemSize={3}
            />
          </bufferGeometry>
          <lineBasicMaterial color="#00ff00" opacity={0.2} transparent />
        </line>
      ))}

      {hypervisors.map((hypervisor, i) => {
        const position = hypervisorPositions.get(hypervisor.ip)!;
        return (
          <Node
            key={hypervisor.ip}
            device={hypervisor}
            position={position}
          />
        );
      })}

      {vms.map((vm, i) => {
        const hypervisorPos = vm.hypervisor?.parent ? hypervisorPositions.get(vm.hypervisor.parent) : null;
        const position = calculateNodePosition(i, vms.length, 3, true, hypervisorPos);
        return (
          <React.Fragment key={vm.ip}>
            {hypervisorPos && (
              <VMConnection start={hypervisorPos} end={position} />
            )}
            <Node
              device={vm}
              position={position}
              isVM={true}
            />
          </React.Fragment>
        );
      })}

      {others.map((device, i) => (
        <Node
          key={device.ip}
          device={device}
          position={calculateNodePosition(i, others.length, 4)}
        />
      ))}
      
      <OrbitControls
        ref={orbitControlsRef}
        enableZoom={true}
        minDistance={5}
        maxDistance={20}
        enablePan={false}
      />

      {/* Zoom controls */}
      <Html position={[-10, 5, 0]}>
        <div className="flex flex-col space-y-2">
          <button
            onClick={handleZoomIn}
            className="p-2 bg-[#111111] border border-[#00ff00] rounded hover:bg-[#222222] transition-colors"
          >
            <ZoomIn className="h-5 w-5 text-[#00ff00]" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-2 bg-[#111111] border border-[#00ff00] rounded hover:bg-[#222222] transition-colors"
          >
            <ZoomOut className="h-5 w-5 text-[#00ff00]" />
          </button>
        </div>
      </Html>
    </group>
  );
}

function RouterInfo() {
  return (
    <div className="bg-[#111111]/90 border border-[#00ff00] p-3 rounded-lg shadow-lg backdrop-blur-sm">
      <div className="flex items-center space-x-2 mb-2 text-[#00ff00]">
        <RouterIcon className="h-5 w-5" />
        <span className="font-bold">Main Router</span>
      </div>
      
      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-[#00ff00]" />
            <span>WAN IP</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.1</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wifi className="h-4 w-4 text-[#00ff00]" />
            <span>Network</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.0/24</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="h-4 w-4 text-[#00ff00]" />
            <span>Status</span>
          </div>
          <span className="text-[#00ff00]">Active</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Network className="h-4 w-4 text-[#00ff00]" />
            <span>Connected Devices</span>
          </div>
          <span className="text-[#00ff00]">24</span>
        </div>
      </div>
    </div>
  );
}

export function NetworkMap({ networkData }: NetworkMapProps) {
  const hasCompromisedDevices = networkData?.devices.some(d => d.status === 'compromised');

  return (
    <div className="cyber-panel h-[600px] relative grid-bg">
      <Canvas>
        <Scene networkData={networkData} />
      </Canvas>
      
      {hasCompromisedDevices && (
        <div className="absolute top-4 right-4 flex items-center space-x-2 text-[#ff0033]">
          <AlertTriangle className="h-5 w-5" />
          <span>THREAT DETECTED</span>
        </div>
      )}
      
      <div className="absolute bottom-4 left-4 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-2">
            <RouterIcon className="h-4 w-4 text-[#00ff00]" />
            <span>Router</span>
          </div>
          <div className="flex items-center space-x-2">
            <Server className="h-4 w-4 text-[#00f7ff]" />
            <span>Server</span>
          </div>
          <div className="flex items-center space-x-2">
            <Monitor className="h-4 w-4 text-[#00f7ff]" />
            <span>Desktop/VM</span>
          </div>
          <div className="flex items-center space-x-2">
            <Laptop className="h-4 w-4 text-[#00f7ff]" />
            <span>Laptop</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-[#00f7ff]" />
            <span>Storage</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#ff0033]"></div>
            <span>Compromised</span>
          </div>
        </div>
      </div>
    </div>
  );
}