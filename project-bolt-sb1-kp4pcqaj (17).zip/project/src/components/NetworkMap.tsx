import React, { useRef, useEffect, useMemo, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';
import { 
  AlertTriangle, 
  Monitor, 
  Server, 
  Laptop, 
  Smartphone, 
  Router as RouterIcon,
  Database,
  Printer,
  Network,
  HardDrive,
  Wifi,
  Globe,
  Activity
} from 'lucide-react';

interface Port {
  port: number;
  state: string;
  service: string;
  version: string;
  product: string;
}

interface Device {
  ip: string;
  hostname: string;
  os: {
    name: string;
    accuracy: number;
    family: string;
  };
  ports: Port[];
  status: string;
  last_seen: number;
}

interface NetworkData {
  devices: Device[];
  metrics: {
    cpu_usage: number;
    memory_total: number;
    memory_used: number;
    memory_free: number;
  };
  timestamp: number;
}

interface NetworkMapProps {
  networkData: NetworkData | null;
}

function calculateNodePosition(index: number, total: number, radius: number = 4): [number, number, number] {
  const phi = Math.acos(-1 + (2 * index) / total);
  const theta = Math.sqrt(total * Math.PI) * phi;
  
  const x = radius * Math.cos(theta) * Math.sin(phi);
  const y = radius * Math.sin(theta) * Math.sin(phi);
  const z = radius * Math.cos(phi);
  
  return [x, y, z];
}

function getDeviceIcon(device: Device) {
  const hostname = device.hostname.toLowerCase();
  const osName = device.os.name.toLowerCase();
  const ports = device.ports.map(p => p.port);

  if (ports.includes(3389) || hostname.includes('desktop') || osName.includes('windows')) {
    return Monitor;
  }

  if (ports.includes(22) || hostname.includes('server') || hostname.includes('srv')) {
    return Server;
  }

  if (hostname.includes('printer') || ports.includes(631)) {
    return Printer;
  }

  if (hostname.includes('nas') || hostname.includes('storage')) {
    return Database;
  }

  if (hostname.includes('mobile') || hostname.includes('phone')) {
    return Smartphone;
  }

  if (hostname.includes('laptop')) {
    return Laptop;
  }

  return HardDrive;
}

function DataFlow({ start, end }) {
  const ref = useRef();
  const [particles, setParticles] = useState([]);
  
  useEffect(() => {
    const particleCount = 5;
    const newParticles = [];
    
    for (let i = 0; i < particleCount; i++) {
      newParticles.push({
        progress: i / particleCount,
        speed: 0.5 + Math.random() * 0.5,
      });
    }
    
    setParticles(newParticles);
  }, []);

  useFrame((state) => {
    if (ref.current) {
      particles.forEach((particle, i) => {
        particle.progress = (particle.progress + particle.speed * 0.01) % 1;
        
        const x = start[0] + (end[0] - start[0]) * particle.progress;
        const y = start[1] + (end[1] - start[1]) * particle.progress;
        const z = start[2] + (end[2] - start[2]) * particle.progress;
        
        const mesh = ref.current.children[i];
        mesh.position.set(x, y, z);
        mesh.scale.setScalar(0.05 + Math.sin(state.clock.elapsedTime * 4 + i) * 0.02);
      });
    }
  });

  return (
    <group ref={ref}>
      {particles.map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.05, 8, 8]} />
          <meshBasicMaterial
            color="#00ff00"
            transparent
            opacity={0.6}
          />
        </mesh>
      ))}
    </group>
  );
}

function Node({ device, position, onHover }: { 
  device: Device; 
  position: [number, number, number];
  onHover: (isHovered: boolean) => void;
}) {
  const [hovered, setHovered] = useState(false);
  const DeviceIcon = getDeviceIcon(device);

  const getNodeColor = (status: string) => {
    switch (status) {
      case 'compromised': return '#ff0033';
      case 'warning': return '#f59e0b';
      default: return '#00f7ff';
    }
  };

  const handleHover = (isHovered: boolean) => {
    setHovered(isHovered);
    onHover(isHovered);
  };

  const color = getNodeColor(device.status);

  return (
    <group position={position}>
      <Html center>
        <div 
          className="device-icon"
          onPointerOver={() => handleHover(true)}
          onPointerOut={() => handleHover(false)}
        >
          <DeviceIcon 
            className="h-6 w-6"
            style={{ 
              color,
              filter: `drop-shadow(0 0 4px ${color})`,
              opacity: hovered ? 1 : 0.8,
            }}
          />
        </div>
      </Html>

      <Html position={[0, -0.8, 0]} center>
        <div className="text-[#00f7ff] text-xs whitespace-nowrap bg-[#111111]/80 px-2 py-1 rounded">
          {device.ip}
        </div>
      </Html>

      {hovered && (
        <Html position={[0, 0.8, 0]}>
          <div className="bg-[#111111] border border-[#00f7ff] p-2 rounded text-xs text-[#00f7ff] whitespace-nowrap">
            <div>{device.hostname}</div>
            <div>OS: {device.os.name}</div>
            <div>Ports: {device.ports.map(p => p.port).join(', ')}</div>
            <div className={`capitalize ${device.status === 'compromised' ? 'text-[#ff0033]' : ''}`}>
              Status: {device.status}
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function Scene({ networkData }: { networkData: NetworkData | null }) {
  const { camera } = useThree();
  const [showRouterInfo, setShowRouterInfo] = useState(false);
  const [hoveredDevice, setHoveredDevice] = useState<string | null>(null);
  
  useEffect(() => {
    camera.position.set(0, 0, 10);
    camera.lookAt(0, 0, 0);
  }, [camera]);

  if (!networkData?.devices) {
    return null;
  }

  return (
    <group>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1.5} />
      
      {/* Router */}
      <group
        onPointerOver={() => setShowRouterInfo(true)}
        onPointerOut={() => setShowRouterInfo(false)}
      >
        <Html center>
          <div className="device-icon transform scale-125">
            <RouterIcon 
              className="h-8 w-8"
              style={{ 
                color: '#00ff00',
                filter: 'drop-shadow(0 0 6px #00ff00)',
              }}
            />
          </div>
          {showRouterInfo && (
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 z-50 whitespace-nowrap">
              <RouterInfo />
            </div>
          )}
        </Html>
      </group>

      {/* Network Connections and Devices */}
      {networkData.devices.map((device, i) => {
        const position = calculateNodePosition(i, networkData.devices.length);
        const isHovered = hoveredDevice === device.ip;

        return (
          <group key={device.ip}>
            <DataFlow 
              start={[0, 0, 0]} 
              end={position}
              active={isHovered}
            />
            <Node 
              device={device} 
              position={position}
              onHover={(hovered) => setHoveredDevice(hovered ? device.ip : null)}
            />
          </group>
        );
      })}

      <OrbitControls
        enableZoom={true}
        minDistance={5}
        maxDistance={20}
        enablePan={false}
      />
    </group>
  );
}

function RouterInfo() {
  return (
    <div className="bg-[#111111]/90 border border-[#00ff00] p-3 rounded-lg shadow-lg backdrop-blur-sm">
      <div className="flex items-center space-x-2 mb-2 text-[#00ff00]">
        <RouterIcon className="h-5 w-5" />
        <span className="font-bold">Main Router</span>
      </div>
      
      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-[#00ff00]" />
            <span>WAN IP</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.1</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wifi className="h-4 w-4 text-[#00ff00]" />
            <span>Network</span>
          </div>
          <span className="text-[#00ff00]">192.168.1.0/24</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="h-4 w-4 text-[#00ff00]" />
            <span>Status</span>
          </div>
          <span className="text-[#00ff00]">Active</span>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Network className="h-4 w-4 text-[#00ff00]" />
            <span>Connected Devices</span>
          </div>
          <span className="text-[#00ff00]">24</span>
        </div>
      </div>
    </div>
  );
}

export function NetworkMap({ networkData }: NetworkMapProps) {
  const hasCompromisedDevices = networkData?.devices.some(d => d.status === 'compromised');

  return (
    <div className="cyber-panel h-[600px] relative grid-bg">
      <Canvas>
        <Scene networkData={networkData} />
      </Canvas>
      
      {hasCompromisedDevices && (
        <div className="absolute top-4 right-4 flex items-center space-x-2 text-[#ff0033]">
          <AlertTriangle className="h-5 w-5" />
          <span>THREAT DETECTED</span>
        </div>
      )}
      
      <div className="absolute bottom-4 left-4 text-xs">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-2">
            <RouterIcon className="h-4 w-4 text-[#00ff00]" />
            <span>Router</span>
          </div>
          <div className="flex items-center space-x-2">
            <Server className="h-4 w-4 text-[#00f7ff]" />
            <span>Server</span>
          </div>
          <div className="flex items-center space-x-2">
            <Monitor className="h-4 w-4 text-[#00f7ff]" />
            <span>Desktop</span>
          </div>
          <div className="flex items-center space-x-2">
            <Laptop className="h-4 w-4 text-[#00f7ff]" />
            <span>Laptop</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="h-4 w-4 text-[#00f7ff]" />
            <span>Storage</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#f59e0b]"></div>
            <span>Warning</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#ff0033]"></div>
            <span>Compromised</span>
          </div>
        </div>
      </div>
    </div>
  );
}