import React from 'react';
import { AlertTriangle, Shield, Loader2 } from 'lucide-react';
import { z } from 'zod';

const InsightSchema = z.object({
  severity: z.enum(['low', 'medium', 'high', 'critical']),
  title: z.string(),
  description: z.string(),
  recommendation: z.string().optional(),
});

const InsightsResponseSchema = z.object({
  insights: z.array(InsightSchema),
  timestamp: z.number().optional(),
});

type Insight = z.infer<typeof InsightSchema>;

interface CustomInsightsPanelProps {
  insights: Insight[] | null;
  isLoading: boolean;
  error: string | null;
}

function getSeverityColor(severity: Insight['severity']) {
  switch (severity) {
    case 'critical': return '#ff0033';
    case 'high': return '#f59e0b';
    case 'medium': return '#facc15';
    case 'low': return '#00ff00';
  }
}

export function CustomInsightsPanel({ insights, isLoading, error }: CustomInsightsPanelProps) {
  if (isLoading) {
    return (
      <div className="cyber-panel p-4 h-[400px] flex items-center justify-center">
        <div className="flex items-center space-x-2 text-[#00f7ff]">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Analyzing network security...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="cyber-panel p-4 h-[400px]">
        <div className="flex items-center space-x-2 text-[#ff0033] mb-4">
          <AlertTriangle className="h-5 w-5" />
          <h3 className="text-sm neon-text">API ERROR</h3>
        </div>
        <p className="text-sm opacity-80">{error}</p>
      </div>
    );
  }

  if (!insights || insights.length === 0) {
    return (
      <div className="cyber-panel p-4 h-[400px] flex items-center justify-center">
        <div className="flex items-center space-x-2 text-[#00f7ff]">
          <Shield className="h-5 w-5" />
          <span>No security insights available</span>
        </div>
      </div>
    );
  }

  return (
    <div className="cyber-panel p-4 h-[400px] overflow-auto">
      <h3 className="text-sm mb-4 neon-text">SECURITY INSIGHTS</h3>
      <div className="space-y-4">
        {insights.map((insight, index) => (
          <div
            key={index}
            className="cyber-panel p-3 widget-enter"
            style={{ borderColor: getSeverityColor(insight.severity) }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {insight.severity === 'critical' || insight.severity === 'high' ? (
                  <AlertTriangle className="h-4 w-4" style={{ color: getSeverityColor(insight.severity) }} />
                ) : (
                  <Shield className="h-4 w-4" style={{ color: getSeverityColor(insight.severity) }} />
                )}
                <span className="font-medium">{insight.title}</span>
              </div>
              <div
                className="text-xs px-2 py-1 rounded capitalize"
                style={{
                  backgroundColor: `${getSeverityColor(insight.severity)}20`,
                  color: getSeverityColor(insight.severity)
                }}
              >
                {insight.severity}
              </div>
            </div>
            <p className="text-sm opacity-80 mb-2">{insight.description}</p>
            {insight.recommendation && (
              <div className="text-sm mt-2 p-2 bg-[#111111] rounded">
                <span className="text-[#00f7ff]">Recommendation:</span>
                <p className="mt-1 opacity-80">{insight.recommendation}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}