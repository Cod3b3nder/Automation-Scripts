import http.server
import socketserver
import json
import os
import socket
import struct
import threading
import time
import logging
import platform
import psutil
import nmap
from pathlib import Path
from typing import Dict, List, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('network_monitor.log'),
        logging.StreamHandler()
    ]
)

class NetworkScanner:
    def __init__(self):
        self.last_scan = 0
        self.scan_interval = 30  # seconds
        self.rate_limit = 100  # requests per scan
        self._lock = threading.Lock()
        self._cache = {}
        self.scanning = False
        self.nm = nmap.PortScanner()

    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system metrics."""
        try:
            logging.info("Getting system metrics...")
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            metrics = {
                'cpu_usage': cpu_percent,
                'memory_total': memory.total,
                'memory_used': memory.used,
                'memory_free': memory.available
            }
            logging.info(f"System metrics: {metrics}")
            return metrics
        except Exception as e:
            logging.error(f"Error getting system metrics: {e}")
            return {}

    def get_network_devices(self) -> List[Dict[str, Any]]:
        """Get network devices information using Nmap."""
        try:
            logging.info("Scanning network devices...")
            devices = []
            
            # Get local IP to determine network range
            hostname = socket.gethostname()
            local_ip = socket.gethostbyname(hostname)
            network_range = '.'.join(local_ip.split('.')[:-1]) + '.0/24'
            
            logging.info(f"Scanning network range: {network_range}")
            
            # Perform Nmap scan
            self.nm.scan(network_range, arguments='-sn')
            hosts = self.nm.all_hosts()
            
            logging.info(f"Found {len(hosts)} hosts")
            
            for host in hosts:
                try:
                    # Get hostname
                    try:
                        hostname = socket.gethostbyaddr(host)[0]
                    except socket.herror:
                        hostname = "Unknown"
                    
                    # Perform detailed scan on the host
                    self.nm.scan(host, arguments='-sS -sV -O')
                    
                    # Get OS information
                    os_info = {
                        'name': 'Unknown',
                        'accuracy': 0,
                        'family': 'Unknown'
                    }
                    if 'osmatch' in self.nm[host]:
                        match = self.nm[host]['osmatch'][0]
                        os_info = {
                            'name': match['name'],
                            'accuracy': int(match['accuracy']),
                            'family': match['osclass'][0]['osfamily']
                        }
                    
                    # Get ports information
                    ports = []
                    if 'tcp' in self.nm[host]:
                        for port, data in self.nm[host]['tcp'].items():
                            ports.append({
                                'port': port,
                                'state': data['state'],
                                'service': data['name'],
                                'version': data.get('version', ''),
                                'product': data.get('product', '')
                            })
                    
                    # Determine device status based on open ports and services
                    status = 'safe'
                    suspicious_ports = [21, 22, 23, 3389]  # FTP, SSH, Telnet, RDP
                    open_suspicious = any(p['port'] in suspicious_ports and p['state'] == 'open' for p in ports)
                    if open_suspicious:
                        status = 'warning'
                    
                    devices.append({
                        'ip': host,
                        'hostname': hostname,
                        'os': os_info,
                        'ports': ports,
                        'status': status,
                        'last_seen': time.time()
                    })
                    
                    logging.info(f"Added device: {host} ({hostname})")
                
                except Exception as e:
                    logging.error(f"Error processing host {host}: {e}")
                    continue
            
            return devices
            
        except Exception as e:
            logging.error(f"Error scanning network devices: {e}")
            return []

    def scan_network(self) -> Dict[str, Any]:
        """Perform network scan."""
        logging.info(f"Scanning network (scanning={self.scanning})")
        
        if not self.scanning:
            logging.info("Scanning is disabled")
            return {
                'devices': [],
                'metrics': self.get_system_metrics(),
                'timestamp': time.time(),
                'scanning': False
            }

        current_time = time.time()
        
        # Rate limiting
        if current_time - self.last_scan < self.scan_interval:
            logging.info("Using cached data due to rate limiting")
            return self._cache
            
        with self._lock:
            try:
                logging.info("Performing new network scan")
                devices = self.get_network_devices()
                metrics = self.get_system_metrics()
                
                self._cache = {
                    'devices': devices,
                    'metrics': metrics,
                    'timestamp': current_time,
                    'scanning': self.scanning
                }
                self.last_scan = current_time
                
                logging.info(f"Scan complete. Found {len(devices)} devices")
                return self._cache
                
            except Exception as e:
                logging.error(f"Error during network scan: {e}")
                return self._cache

    def start_scanning(self):
        """Start network scanning."""
        self.scanning = True
        logging.info("Network scanning started")

    def stop_scanning(self):
        """Stop network scanning."""
        self.scanning = False
        logging.info("Network scanning stopped")

class NetworkMonitorHandler(http.server.SimpleHTTPRequestHandler):
    scanner = NetworkScanner()
    
    def send_cors_headers(self):
        """Send CORS headers."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
    
    def do_OPTIONS(self):
        """Handle OPTIONS request."""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def do_GET(self):
        """Handle GET request."""
        if self.path == '/api/network':
            try:
                data = self.scanner.scan_network()
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
            except Exception as e:
                logging.error(f"Error handling request: {e}")
                self.send_error(500, "Internal Server Error")
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        """Handle POST request."""
        if self.path == '/api/network/start':
            self.scanner.start_scanning()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'scanning_started'}).encode())
        elif self.path == '/api/network/stop':
            self.scanner.stop_scanning()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({'status': 'scanning_stopped'}).encode())
        else:
            self.send_error(404, "Not Found")

def run_server(port: int = 5000):
    """Run the network monitoring server."""
    try:
        with socketserver.TCPServer(("", port), NetworkMonitorHandler) as httpd:
            logging.info(f"Server running on port {port}")
            httpd.serve_forever()
    except Exception as e:
        logging.error(f"Server error: {e}")
        raise

if __name__ == "__main__":
    run_server()