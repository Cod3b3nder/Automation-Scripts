import http.server
import socketserver
import json
import os
import socket
import struct
import threading
import time
import logging
import platform
import nmap
import re
import subprocess
import requests
from pathlib import Path
from typing import Dict, List, Any, Optional, Set
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('network_monitor.log'),
        logging.StreamHandler()
    ]
)

class CVEScanner:
    def __init__(self):
        self.cache = {}
        self.cache_duration = timedelta(hours=24)
        self.last_update = None
        self.nvd_api_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
        
    def _is_cache_valid(self) -> bool:
        if not self.last_update:
            return False
        return datetime.now() - self.last_update < self.cache_duration

    def get_cves_for_service(self, service: str, version: str) -> List[Dict[str, Any]]:
        """Get CVEs for a specific service and version."""
        cache_key = f"{service}:{version}"
        
        try:
            # Check cache first
            if cache_key in self.cache and self._is_cache_valid():
                return self.cache[cache_key]

            # Query NVD API
            params = {
                "keywordSearch": f"{service} {version}",
                "resultsPerPage": 10,
                "isVulnerable": True
            }
            
            response = requests.get(self.nvd_api_url, params=params)
            response.raise_for_status()
            
            data = response.json()
            vulnerabilities = []
            
            for vuln in data.get('vulnerabilities', []):
                cve = vuln.get('cve', {})
                metrics = cve.get('metrics', {}).get('cvssMetricV31', [{}])[0].get('cvssData', {})
                
                vulnerability = {
                    'id': cve.get('id', ''),
                    'description': cve.get('descriptions', [{}])[0].get('value', ''),
                    'published': cve.get('published', ''),
                    'score': metrics.get('baseScore', 0),
                    'severity': metrics.get('baseSeverity', 'UNKNOWN'),
                    'references': [ref.get('url') for ref in cve.get('references', [])]
                }
                
                vulnerabilities.append(vulnerability)
            
            # Update cache
            self.cache[cache_key] = vulnerabilities
            self.last_update = datetime.now()
            
            return vulnerabilities
            
        except Exception as e:
            logging.error(f"Error fetching CVEs for {service} {version}: {e}")
            return []

class NetworkScanner:
    def __init__(self):
        self.last_scan = 0
        self.scan_interval = 30  # seconds
        self.rate_limit = 100  # requests per scan
        self._lock = threading.Lock()
        self._cache = {}
        self.nm = nmap.PortScanner()
        self.is_scanning = False
        self.masscan_available = self._check_masscan()
        self.cve_scanner = CVEScanner()
        
        # VM Hypervisor signatures
        self.hypervisor_signatures = {
            'vmware': {
                'mac_prefixes': ['00:50:56', '00:0C:29', '00:05:69'],
                'services': ['vmware-authd', 'vmware-hostd'],
                'os_signatures': ['VMware']
            },
            'virtualbox': {
                'mac_prefixes': ['08:00:27'],
                'services': ['vboxd'],
                'os_signatures': ['VirtualBox']
            },
            'hyper-v': {
                'mac_prefixes': ['00:15:5D'],
                'services': ['hyperv'],
                'os_signatures': ['Hyper-V']
            },
            'kvm': {
                'mac_prefixes': ['52:54:00'],
                'services': ['qemu-system', 'libvirtd'],
                'os_signatures': ['QEMU', 'KVM']
            }
        }

    def _check_masscan(self) -> bool:
        """Check if masscan is available on the system."""
        try:
            subprocess.run(['masscan', '--version'], 
                         stdout=subprocess.PIPE, 
                         stderr=subprocess.PIPE)
            logging.info("Masscan is available")
            return True
        except Exception:
            logging.warning("Masscan is not available, falling back to Nmap only")
            return False

    def _run_masscan(self, network_range: str) -> Set[str]:
        """Run masscan for initial host and port discovery."""
        try:
            cmd = [
                'masscan',
                network_range,
                '--rate=10000',
                '--ports=20-23,25,53,80,110,143,443,445,993,995,1723,3306,3389,5900,8080',
                '--wait=0',
                '-oJ',
                '-'
            ]
            
            process = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            if process.returncode != 0:
                raise Exception(f"Masscan failed: {process.stderr}")
            
            active_hosts = set()
            for line in process.stdout.strip().split('\n'):
                if line and not line.startswith('#'):
                    try:
                        data = json.loads(line)
                        if 'ip' in data:
                            active_hosts.add(data['ip'])
                    except json.JSONDecodeError:
                        continue
            
            return active_hosts
            
        except Exception as e:
            logging.error(f"Error running masscan: {e}")
            return set()

    def detect_hypervisor(self, host_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Detect if a host is a VM or hypervisor."""
        try:
            if 'addresses' in host_info and 'mac' in host_info['addresses']:
                mac = host_info['addresses']['mac']
                for hypervisor, sigs in self.hypervisor_signatures.items():
                    if any(mac.upper().startswith(prefix.upper()) for prefix in sigs['mac_prefixes']):
                        return {
                            'type': 'vm',
                            'hypervisor': hypervisor
                        }

            if 'osmatch' in host_info and len(host_info['osmatch']) > 0:
                os_name = host_info['osmatch'][0]['name']
                for hypervisor, sigs in self.hypervisor_signatures.items():
                    if any(sig.lower() in os_name.lower() for sig in sigs['os_signatures']):
                        return {
                            'type': 'hypervisor',
                            'name': hypervisor
                        }

            if 'tcp' in host_info:
                services = [service['name'] for port, service in host_info['tcp'].items()]
                for hypervisor, sigs in self.hypervisor_signatures.items():
                    if any(service in services for service in sigs['services']):
                        return {
                            'type': 'hypervisor',
                            'name': hypervisor
                        }

            return None
        except Exception as e:
            logging.error(f"Error detecting hypervisor: {e}")
            return None

    def get_system_metrics(self) -> Dict[str, Any]:
        """Get system metrics."""
        try:
            cpu_usage = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            return {
                'cpu_usage': cpu_usage,
                'memory_total': memory.total,
                'memory_used': memory.used,
                'memory_free': memory.available
            }
        except Exception as e:
            logging.error(f"Error getting system metrics: {e}")
            return {}

    def get_network_range(self) -> str:
        """Get the local network range."""
        try:
            if platform.system() == "Windows":
                interface = next((i for i in psutil.net_if_addrs() if "Ethernet" in i or "Wi-Fi" in i), None)
            else:
                interface = next((i for i in psutil.net_if_addrs() if i != "lo"), None)
            
            if not interface:
                raise ValueError("No suitable network interface found")

            addrs = psutil.net_if_addrs()[interface]
            ip_info = next((addr for addr in addrs if addr.family == socket.AF_INET), None)
            
            if not ip_info:
                raise ValueError("No IPv4 address found")

            ip_parts = ip_info.address.split('.')
            return f"{'.'.join(ip_parts[:-1])}.0/24"
            
        except Exception as e:
            logging.error(f"Error getting network range: {e}")
            return "192.168.1.0/24"

    def perform_nmap_scan(self, target: str) -> Dict[str, Any]:
        """Perform detailed Nmap scan on a target."""
        try:
            self.nm.scan(target, arguments='-sS -sV -O --script=virtual-machine-info,vmware-version --version-intensity 5')
            
            if target not in self.nm.all_hosts():
                return None

            host_info = self.nm[target]
            
            os_info = {
                'name': 'Unknown',
                'accuracy': 0,
                'family': 'Unknown'
            }
            
            if 'osmatch' in host_info and host_info['osmatch']:
                best_match = host_info['osmatch'][0]
                os_info = {
                    'name': best_match['name'],
                    'accuracy': best_match['accuracy'],
                    'family': best_match['osclass'][0]['osfamily'] if best_match.get('osclass') else 'Unknown'
                }

            ports_info = []
            vulnerabilities = []
            
            if 'tcp' in host_info:
                for port, data in host_info['tcp'].items():
                    port_info = {
                        'port': port,
                        'state': data['state'],
                        'service': data['name'],
                        'version': data.get('version', ''),
                        'product': data.get('product', '')
                    }
                    ports_info.append(port_info)
                    
                    # Get CVEs for this service
                    if port_info['version'] and port_info['product']:
                        cves = self.cve_scanner.get_cves_for_service(
                            port_info['product'],
                            port_info['version']
                        )
                        vulnerabilities.extend(cves)

            status = 'safe'
            suspicious_ports = {21, 22, 23, 3389}
            open_suspicious = any(p['port'] in suspicious_ports and p['state'] == 'open' for p in ports_info)
            
            if open_suspicious:
                status = 'warning'
            if len([p for p in ports_info if p['state'] == 'open']) > 5:
                status = 'compromised'

            hypervisor_info = self.detect_hypervisor(host_info)

            return {
                'ip': target,
                'hostname': socket.getfqdn(target),
                'os': os_info,
                'ports': ports_info,
                'status': status,
                'last_seen': time.time(),
                'hypervisor': hypervisor_info,
                'vulnerabilities': vulnerabilities
            }
            
        except Exception as e:
            logging.error(f"Error during Nmap scan of {target}: {e}")
            return None

    def scan_network(self) -> Dict[str, Any]:
        """Perform network scan using Masscan for discovery and Nmap for details."""
        if not self.is_scanning:
            return self._cache
            
        current_time = time.time()
        
        if current_time - self.last_scan < self.scan_interval:
            return self._cache
            
        with self._lock:
            try:
                devices = []
                network_range = self.get_network_range()
                active_hosts = set()

                if self.masscan_available:
                    logging.info(f"Starting Masscan discovery on {network_range}")
                    active_hosts = self._run_masscan(network_range)
                    logging.info(f"Masscan found {len(active_hosts)} active hosts")
                
                if not active_hosts:
                    logging.info(f"Using Nmap for host discovery on {network_range}")
                    self.nm.scan(hosts=network_range, arguments='-sn')
                    active_hosts = set(self.nm.all_hosts())
                
                for host in list(active_hosts)[:self.rate_limit]:
                    try:
                        scan_result = self.perform_nmap_scan(host)
                        if scan_result:
                            devices.append(scan_result)
                    except Exception as e:
                        logging.error(f"Error scanning host {host}: {e}")
                        continue

                hypervisors = {}
                vms = []
                other_devices = []

                for device in devices:
                    if device.get('hypervisor'):
                        if device['hypervisor']['type'] == 'hypervisor':
                            hypervisors[device['ip']] = device
                        elif device['hypervisor']['type'] == 'vm':
                            vms.append(device)
                    else:
                        other_devices.append(device)

                for vm in vms:
                    vm['hypervisor']['parent'] = None
                    for hypervisor_ip, hypervisor in hypervisors.items():
                        if vm['hypervisor']['hypervisor'] == hypervisor['hypervisor']['name']:
                            vm['hypervisor']['parent'] = hypervisor_ip
                            break

                self._cache = {
                    'devices': devices,
                    'metrics': self.get_system_metrics(),
                    'timestamp': current_time,
                    'scanning': self.is_scanning
                }
                self.last_scan = current_time
                
                return self._cache
                
            except Exception as e:
                logging.error(f"Error during network scan: {e}")
                return self._cache

class NetworkMonitorHandler(http.server.SimpleHTTPRequestHandler):
    scanner = NetworkScanner()
    
    def send_cors_headers(self):
        """Send CORS headers."""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
    
    def do_OPTIONS(self):
        """Handle OPTIONS request."""
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()
    
    def do_GET(self):
        """Handle GET request."""
        if self.path == '/api/network':
            try:
                data = self.scanner.scan_network()
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
            except Exception as e:
                logging.error(f"Error handling GET request: {e}")
                self.send_error(500, "Internal Server Error")
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        """Handle POST request."""
        if self.path == '/api/network/start':
            try:
                self.scanner.is_scanning = True
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'scanning_started'}).encode())
            except Exception as e:
                logging.error(f"Error handling start scan request: {e}")
                self.send_error(500, "Internal Server Error")
        
        elif self.path == '/api/network/stop':
            try:
                self.scanner.is_scanning = False
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({'status': 'scanning_stopped'}).encode())
            except Exception as e:
                logging.error(f"Error handling stop scan request: {e}")
                self.send_error(500, "Internal Server Error")
        
        else:
            self.send_error(404, "Not Found")

def run_server(port: int = 5000):
    """Run the network monitoring server."""
    try:
        with socketserver.TCPServer(("", port), NetworkMonitorHandler) as httpd:
            logging.info(f"Server running on port {port}")
            httpd.serve_forever()
    except Exception as e:
        logging.error(f"Server error: {e}")
        raise

if __name__ == "__main__":
    run_server()