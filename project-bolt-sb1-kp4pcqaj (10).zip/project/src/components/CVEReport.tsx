import React from 'react';
import { AlertTriangle, Shield, ExternalLink } from 'lucide-react';

interface Port {
  port: number;
  state: string;
  service: string;
  version: string;
  product: string;
}

interface Vulnerability {
  id: string;
  description: string;
  published: string;
  score: number;
  severity: string;
  references: string[];
}

interface Device {
  ip: string;
  hostname: string;
  os: {
    name: string;
    accuracy: number;
    family: string;
  };
  ports: Port[];
  status: string;
  last_seen: number;
  vulnerabilities: Vulnerability[];
}

interface CVEReport {
  devices: Device[] | undefined;
}

function getVulnerabilityLevel(score: number): { color: string; label: string } {
  if (score >= 9.0) return { color: '#ff0033', label: 'CRITICAL' };
  if (score >= 7.0) return { color: '#f59e0b', label: 'HIGH' };
  if (score >= 4.0) return { color: '#facc15', label: 'MEDIUM' };
  return { color: '#00ff00', label: 'LOW' };
}

export function CVEReport({ devices }: CVEReport) {
  if (!devices) {
    return (
      <div className="flex items-center justify-center h-full">
        <span className="text-[#00f7ff]">Analyzing vulnerabilities...</span>
      </div>
    );
  }

  // Collect all vulnerabilities from devices
  const allVulnerabilities = devices.reduce((acc, device) => {
    if (device.vulnerabilities) {
      device.vulnerabilities.forEach(vuln => {
        const existingVuln = acc.find(v => v.id === vuln.id);
        if (existingVuln) {
          if (!existingVuln.affectedDevices.some(d => d.ip === device.ip)) {
            existingVuln.affectedDevices.push(device);
          }
        } else {
          acc.push({
            ...vuln,
            affectedDevices: [device]
          });
        }
      });
    }
    return acc;
  }, [] as (Vulnerability & { affectedDevices: Device[] })[]);

  // Sort vulnerabilities by score (highest first)
  const sortedVulnerabilities = allVulnerabilities.sort((a, b) => b.score - a.score);

  return (
    <div className="space-y-4 h-full overflow-auto">
      {sortedVulnerabilities.length === 0 ? (
        <div className="text-center text-[#00f7ff] py-4">
          No vulnerabilities detected
        </div>
      ) : (
        sortedVulnerabilities.map(vuln => {
          const level = getVulnerabilityLevel(vuln.score);
          return (
            <div key={vuln.id} className="cyber-panel p-3 space-y-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {vuln.score >= 7.0 ? (
                    <AlertTriangle className="h-4 w-4" style={{ color: level.color }} />
                  ) : (
                    <Shield className="h-4 w-4" style={{ color: level.color }} />
                  )}
                  <span className="font-mono">{vuln.id}</span>
                </div>
                <div 
                  className="text-xs px-2 py-1 rounded"
                  style={{ 
                    backgroundColor: `${level.color}20`,
                    color: level.color
                  }}
                >
                  {level.label} ({vuln.score.toFixed(1)})
                </div>
              </div>

              <div>
                <p className="text-xs opacity-80">{vuln.description}</p>
              </div>

              {vuln.affectedDevices.length > 0 && (
                <div className="text-xs">
                  <div className="mb-1 opacity-80">Affected Devices:</div>
                  <div className="space-y-1">
                    {vuln.affectedDevices.map(device => (
                      <div 
                        key={device.ip}
                        className="flex items-center justify-between p-1 bg-[#111111] rounded"
                      >
                        <span>{device.hostname} ({device.ip})</span>
                        <span className="opacity-60">
                          {device.os.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {vuln.references.length > 0 && (
                <div className="text-xs pt-2 border-t border-[#222222]">
                  <div className="flex items-center space-x-1">
                    <ExternalLink className="h-3 w-3" />
                    <a 
                      href={vuln.references[0]}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#00f7ff] hover:underline"
                    >
                      View in NVD Database
                    </a>
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}